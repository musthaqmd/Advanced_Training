package com.org.day1;

import java.util.Scanner;

public class StringOperations {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// taking string from user
		System.out.println("Enter a String:");
		String s = sc.nextLine();

		// finding length of the string
		int len = s.length();

		// converting string to uppercase
		String upper = s.toUpperCase();
		System.out.println("Length: " + len);
		System.out.println("UpperCase: " + upper);

		int i = 0, j = len - 1, flag = 0;
		// checking if string is palindrome or not
		while (i < j) {
			if (upper.charAt(i) != upper.charAt(j))
				flag = 1;
			i++;
			j--;
		}
		if (flag == 1)
			System.out.println("Not Palindrome");
		else
			System.out.println("Palindrome");
	}

}
