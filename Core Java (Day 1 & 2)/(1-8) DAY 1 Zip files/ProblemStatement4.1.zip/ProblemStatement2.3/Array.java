package com.org.day1;

public class Array {

	public static void main(String[] args) {
		
		int A[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		int i,j,s=0,avg=0,min=0;
		
		//calculating sum and average of numbers from index 0 to 14
		for(i=0;i<=14;i++)
		{
			s=s+A[i];
		}
		A[15]=s;
		avg=s/14;
		A[16]=avg;
		
		//calculating minimum number from index 0 to 14
		for(i=0;i<=14;i++)
		{
			for(j=i+1;j<=14;j++)
			{
				if(A[i]<A[i+1])
				{
					min=A[i];
					A[i]=A[j];
					A[j]=min;
				}
					
			}
			
		}
		A[17]=min;
		
		//printing array
		for(i=0;i<=17;i++)
		{
			System.out.print(A[i]+" ");
		}
		
	}
	
}
