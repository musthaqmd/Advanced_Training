package com.org.day1;

import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CopyFile {

	public static void main(String[] args) throws IOException {
		Scanner s = new Scanner(System.in);
		FileReader r = null;
		FileWriter w = null;
		try {
			//taking directory path and file name of the source and destination files from the user
			System.out.println("Enter directory path and filename of the Source file:");
			String file1 = s.nextLine();
			r = new FileReader(file1);
			System.out.println("Enter directory path and filename of the Destination file:");
			String file2 = s.nextLine();

			File f = new File(file2);
			//checking if file exists, if not then a new file is created
			if (!f.exists()) {
				w = new FileWriter(file2);
				f.createNewFile();
				int c = r.read();
				while (c != -1) {
					w.write(c);
					c = r.read();
				}
				System.out.println("File copied successfully");
			} else {
				w = new FileWriter(file2);
				System.out.println("Do you want to overwrite? Enter 'yes' or 'no'...");
				char ans = s.next().charAt(0);

				if (ans == 'N' || ans == 'n') {
					System.out.println("Data not overwritten");
				} else {
					int c = r.read();
					while (c != -1) {
						w.write(c);
						c = r.read();
					}
					System.out.println("File updated successfully");
				}
			}
		} catch (IOException e) {
			System.out.println("File could not be found");
		} finally {
			close(r);
			close(w);
		}
	}

	public static void close(Closeable stream) {
		try {
			if (stream != null) {
				stream.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
