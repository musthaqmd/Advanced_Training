package com.org.day1;

abstract class Instrument {

	public abstract void play();
}
