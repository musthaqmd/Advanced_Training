package com.org.day1;

public class InstrumentMain {

	public static void main(String[] args) {

		//creating array of 10 Instrument objects
		Instrument a[] = new Instrument[10];

		a[0]=new Piano();
		a[1]=new Piano();
		a[2]=new Flute();
		a[3]=new Guitar();
		a[4]=new Guitar();
		a[5]=new Flute();
		a[6]=new Piano();
		a[7]=new Guitar();
		a[8]=new Flute();
		a[9]=new Piano();

		//calling method play and using instanceof to print which object is stored at which index
		for (int i = 0; i<10; i++) 
		{
			a[i].play();
			if (a[i] instanceof Piano)
				System.out.println("Piano");
			if (a[i] instanceof Flute)
				System.out.println("Flute");
			if (a[i] instanceof Guitar)
				System.out.println("Guitar");
		}
	}
}
