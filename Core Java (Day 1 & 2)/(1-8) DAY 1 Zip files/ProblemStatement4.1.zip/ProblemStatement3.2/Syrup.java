package com.org.day1;

public class Syrup implements MedicineInfo {

	@Override
	public void displayLabel() {
		
		System.out.println("Use before Expire date");
	}
}
