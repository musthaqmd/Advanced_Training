package com.org.day1;

import java.util.Random;

public class TestMedicine {

	public static void main(String[] args) {
		
		//creating array of 10 Medicine objects
		MedicineInfo a[]=new MedicineInfo[10];
		
		//using RandomNumberGenerator
		Random r=new Random();
		int limit=3;
		int random=r.nextInt(limit);
		System.out.println(random);
		
		switch(random)
		{
			case 0:
				a[0]=new Tablet();
				a[3]=new Syrup();
				a[0].displayLabel();
				a[3].displayLabel();
				break;
			case 1:
				a[1]=new Syrup();
				a[4]=new Ointment();
				a[1].displayLabel();
				a[4].displayLabel();
				break;
			case 2:
				a[2]=new Ointment();
				a[5]=new Tablet();
				a[2].displayLabel();
				a[5].displayLabel();
				break;
		}
	}
}
