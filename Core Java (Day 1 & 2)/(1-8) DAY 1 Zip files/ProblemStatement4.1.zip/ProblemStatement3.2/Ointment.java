package com.org.day1;

public class Ointment implements MedicineInfo {

	@Override
	public void displayLabel() {
		
		System.out.println("For external use only");
	}
}
