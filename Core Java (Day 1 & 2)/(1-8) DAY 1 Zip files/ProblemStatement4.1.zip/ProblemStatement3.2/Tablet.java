package com.org.day1;

public class Tablet implements MedicineInfo {

	@Override
	public void displayLabel() {
		
		System.out.println("Store in a cool dry place");
	}
}
