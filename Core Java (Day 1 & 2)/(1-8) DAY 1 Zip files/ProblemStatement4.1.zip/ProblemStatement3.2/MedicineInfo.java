package com.org.day1;

public interface MedicineInfo {

	public abstract void displayLabel();
}
