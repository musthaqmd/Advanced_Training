package com.org.day1;

public class NegativeAmountException extends Exception {

	public NegativeAmountException(String msg)
	{
		super(msg);
	}
}
