package com.org.day1;

public class LowBalanceException extends Exception {

	public LowBalanceException(String msg)
	{
		super(msg);
	}
}
