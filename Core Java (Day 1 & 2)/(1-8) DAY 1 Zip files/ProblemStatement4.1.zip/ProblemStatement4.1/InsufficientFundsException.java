package com.org.day1;

public class InsufficientFundsException extends Exception {

	public InsufficientFundsException(String msg)
	{
		super(msg);
	}
}
