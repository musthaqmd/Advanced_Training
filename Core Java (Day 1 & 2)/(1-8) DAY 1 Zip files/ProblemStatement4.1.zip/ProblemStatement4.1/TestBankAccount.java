package com.org.day1;

public class TestBankAccount {

	public static void main(String[] args) {
		
		//creating object of BankAccount
		BankAccount b=new BankAccount();
		b.withdraw(200);
		b.deposit(700);
		b.display();
		b.withdraw(200);
		b.getBalance();
		b.display();
	}
}
