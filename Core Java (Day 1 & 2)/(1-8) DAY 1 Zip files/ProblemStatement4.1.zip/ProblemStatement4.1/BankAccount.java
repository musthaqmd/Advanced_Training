package com.org.day1;

public class BankAccount {

	private int accNo;
	private String custName;
	private String accType;
	private float balance;

	// getters and setters
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}
	
	//checking if balance is less than minimum balance
	public float getBalance() {
		if (balance < 1000) {
			try {
				throw new LowBalanceException("Balance Low");
			} catch (LowBalanceException e) {
				System.out.println("Balance is low");
			}
		}
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	//default constructor
	public BankAccount() {
		this.accNo = 10001;
		this.custName = "ABC";
		this.accType = "Savings";
		this.balance = 500.0f;
	}

	//parameterized constructor
	public BankAccount(int accNo, String custName, String accType, float balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.accType = accType;
		this.balance = balance;
	}

	//to deposit amount into account
	public void deposit(float amt) {
		//checking if amount to be deposited is negative or not
		if (amt < 0) {
			try {
				throw new NegativeAmountException("Amount cannot be negative");
			} catch (NegativeAmountException e) {
				System.out.println("Negative Amount can't be deposited");
			}
		} else {
			balance = getBalance() + amt;
			System.out.println("Current balance is: " + balance);
		}
	}

	//to withdraw amount from account
	public void withdraw(float amt) {
		balance = getBalance();
		if ((balance - amt) < 1000) {
			try {
				throw new InsufficientFundsException("Insufficient Funds");
			} catch (InsufficientFundsException e) {
				System.out.println("Withdraw unsuccessful, Insufficient Funds");
			}
		} else {
			balance = getBalance() - amt;
			System.out.println("Current balance is: " + balance);
		}
	}

	//to display balance
	public void display() {
		System.out.println("Balance: " + getBalance());
	}

}
