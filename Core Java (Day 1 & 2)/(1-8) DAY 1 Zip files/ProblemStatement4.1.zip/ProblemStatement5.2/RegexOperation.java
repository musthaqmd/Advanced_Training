package com.org.day1;

import java.util.Scanner;

public class RegexOperation {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// taking mathematical expression from user
		System.out.println("Enter mathematical expression:");
		String s = sc.nextLine();

		// displaying each token of the mathematical expression separately
		String[] newstr = s.split("(?<=[()-+*/])|(?=[-+*/()])");
		for (String str : newstr) {
			System.out.println(str.replace(" ", ""));
		}
	}
}
