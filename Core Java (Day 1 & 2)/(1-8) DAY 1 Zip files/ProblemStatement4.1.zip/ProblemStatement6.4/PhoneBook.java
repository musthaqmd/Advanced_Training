package com.org.day1;

import java.util.HashMap;
import java.util.Scanner;

public class PhoneBook {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// declaring a HashMap of type String,Long
		HashMap<String, Long> map = new HashMap<String, Long>();
		int ch;

		// to ensure that switch case executes repeatedly unless user inputs 3
		do {
			System.out.println("-------Menu-------");
			System.out.println("1.Add new PhoneBook entry\n2.Search Phone number\n3.Quit");
			System.out.println("Enter your choice:");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				Scanner s1 = new Scanner(System.in);
				String name;
				long pnumber;

				// taking name and phone number from user
				System.out.println("Enter Name and Phone number:");
				name = s1.nextLine();
				pnumber = s1.nextLong();

				// inserting details into the HashMap
				map.put(name, pnumber);
				System.out.println(map);
				break;
			case 2:
				Scanner s2 = new Scanner(System.in);
				String n;

				// taking name from user
				System.out.println("Enter Name:");
				n = s2.nextLine();

				// checking if details is present in the HashMap or not
				if (map.get(n) == null)
					System.out.println("Record not found");
				else
					System.out.println("Phone number: " + map.get(n));
				break;
			case 3:
				System.out.println("Closed");
				break;
			default:
				System.out.println("Please enter valid choice");
			}
		} while (ch != 3);
	}

}
