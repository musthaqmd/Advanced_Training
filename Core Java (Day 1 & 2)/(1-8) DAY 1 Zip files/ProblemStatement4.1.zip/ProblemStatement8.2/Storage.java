package com.org.day1;

public class Storage {

	int i;
	boolean printed = true;

	//getters and setters
	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setPrinted(boolean printed) {
		this.printed = printed;
	}

}
