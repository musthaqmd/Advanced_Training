package com.org.day1;

public class Counter implements Runnable {

	Storage s;

	public Counter(Storage s) {

		this.s = s;
	}

	@Override
	public void run() {
		synchronized (s) {
			for (int i = 0; i < 10; i++) {
				while (!s.isPrinted())
				{
					try {
						s.wait();
					} catch (Exception e) {
					}
				}
				s.setI(i);
				s.setPrinted(false);
				s.notify();
			}
		}

	}
}
