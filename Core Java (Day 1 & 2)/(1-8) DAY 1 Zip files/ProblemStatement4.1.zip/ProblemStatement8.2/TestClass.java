package com.org.day1;

public class TestClass {

	public static void main(String[] args) {

		//creating objects of Storage, Counter and Printed
		Storage s = new Storage();
		Counter c = new Counter(s);
		Printer p = new Printer(s);
		
		// start the counter
		new Thread(c, "Counter").start(); 
		
		// start the printer
		new Thread(p, "Printer").start(); 
	}
}
