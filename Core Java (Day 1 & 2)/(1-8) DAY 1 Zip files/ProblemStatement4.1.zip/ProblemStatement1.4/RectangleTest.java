package com.org.day1;

import java.util.Scanner;

public class RectangleTest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		float l = 0.0f, w = 0.0f;
		
		//taking length and width from user
		System.out.println("Enter Length and Width of the Rectangle:");
		l = sc.nextFloat();
		w = sc.nextFloat();
		
		//creating object of Rectangle
		Rectangle r=new Rectangle();
		r.perimeter();
		r.area();
		r.setLength(l);
		r.setWidth(w);
		r.perimeter();
		r.area();
	}
}
