package com.org.day1;

public class Rectangle {

	private float length;
	private float width;
	
	//default constructor
	public Rectangle() {
		this.length=1.0f;
		this.width=1.0f;
	}

	//parameterized constructor
	public Rectangle(float length, float width) {

		this.length = length;
		this.width = width;
	}

	//getters and setters
	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		
		//checking whether length is greater than or equal to 0 or length is greater than 20
		if(length<=0.0 || length>20.0)
		{
			System.out.println("Please enter valid length and width");
		}
		else
			this.length = length;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {

		//checking whether width is greater than or equal to 0 or length is greater than 20
		if(width<=0.0 || width>20.0)
		{
			System.out.println("Please enter valid length and width");
		}
		else
			this.width = width;
	}
	
	//calculate perimeter of the rectangle
	public void perimeter()
	{
		float p = 2*(length+width);
		System.out.println("Perimeter is: "+p);
	}
	
	//calculate area of the rectangle
	public void area()
	{
		float a = length*width;
		System.out.println("Area is: "+a);
	}
}
