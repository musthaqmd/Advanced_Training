package com.org.day1;

import java.util.Scanner;

public class StringOperation {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// taking string from user
		System.out.println("Enter the String:");
		String str = sc.nextLine();

		// finding length of the given string
		int len = str.length();
		System.out.println(str);

		// deletes first letter of the string and adds it to the end of the string
		for (int i = 0; i < len; i++) {
			char s = str.charAt(0);
			String s1 = str.substring(1);
			String s2 = s1 + s;
			System.out.println(s2);
			str = s2;
		}
	}
}
