package com.org.day1;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class TestEmployee {

	// add details into the linked list
	public static LinkedList<Employee> addInput() {
		// creating objects of Employee
		Employee e1 = new Employee(1001, "ABC", "ABCDEF");
		Employee e2 = new Employee(1002, "DEF", "DEFGHI");

		// declaring linked list of type Employee
		LinkedList<Employee> list = new LinkedList<Employee>();

		// adding details into the linked list
		list.add(e1);
		list.add(e2);
		return list;
	}

	// display linked list using iterator and listiterator
	public static void display(LinkedList<Employee> list) {
		ListIterator<Employee> listIterator = list.listIterator();
		while (listIterator.hasNext()) {
			System.out.println(listIterator.next());
		}

		Iterator<Employee> iterator = list.descendingIterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

	public static void main(String[] args) {

		// creating linked list of type Employee
		LinkedList<Employee> list = addInput();
		display(list);
	}
}
