package com.org.day1;

public class AgeNotWithinRangeException extends Exception {

	public String toString() {
		return ("Age is not between 15 and 21. Please re-enter Age");
	}
}
