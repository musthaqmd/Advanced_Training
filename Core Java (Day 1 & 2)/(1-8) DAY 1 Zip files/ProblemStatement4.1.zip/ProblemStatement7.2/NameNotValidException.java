package com.org.day1;

public class NameNotValidException extends Exception {

	public String validname() {
		return ("Name is not Valid, Please re-enter Name");
	}
}
