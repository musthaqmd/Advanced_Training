package com.org.day1;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TestStudent {

	public static void main(String args[]) throws Exception {
		// taking details from user
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter roll number: ");
		int roll = Integer.parseInt(br.readLine());
		System.out.println("\nEnter name: ");
		String name = br.readLine();
		System.out.println("\nEnter age: ");
		int age = Integer.parseInt(br.readLine());
		System.out.println("\nEnter course: ");
		String course = br.readLine();

		// creating object of Student and passing details into it
		Student s = new Student(roll, name, age, course);
		s.display();
	}
}
