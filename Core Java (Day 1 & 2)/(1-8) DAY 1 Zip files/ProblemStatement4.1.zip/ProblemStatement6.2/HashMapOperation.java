package com.org.day1;

import java.util.HashMap;
import java.util.Scanner;

public class HashMapOperation {

	public static void main(String[] args) {

		// declaring HashMap of type String,String
		HashMap<String, String> map = new HashMap<String, String>();

		Scanner sc = new Scanner(System.in);
		String pid, pname;

		// to insert details taken from user into the HashMap
		for (int i = 0; i < 3; i++) {
			System.out.println("Enter Product ID and Product Name:");
			pid = sc.nextLine();
			pname = sc.nextLine();

			map.put(pid, pname);

		}
		// displaying the HashMap
		System.out.println(map);

		// removing a detail from the HashMap
		System.out.println(map.remove("P002"));

		// displaying the HashMap
		System.out.println(map);

	}
}
