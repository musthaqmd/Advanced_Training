package com.org.day1;

public class Counter implements Runnable {

	public static void main(String[] args) {
		Storage store = new Storage();
		Printer p = new Printer(store);
		Counter c = new Counter(store);
	}

	Storage s;

	public Counter(Storage store) {
		s = store;
		new Thread(this, "Counter").start();

	}

	@Override
	public void run() {
		
		//stores each value into Storage
		for (int i = 0; i < 10; i++) {
			synchronized (s) {
				s.setI(i);
				s.notify();
				try {
					s.wait();
				} catch (InterruptedException ie) {
					System.out.println("Interrupted - " + ie.getMessage());
				}
			}
		}

	}
}
