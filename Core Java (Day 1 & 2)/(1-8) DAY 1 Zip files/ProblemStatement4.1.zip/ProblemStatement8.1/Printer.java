package com.org.day1;

public class Printer implements Runnable {

	Storage s;

	public Printer(Storage s) {

		this.s = s;
		new Thread(this, "Printer").start();
	}

	@Override
	public void run() {
		int c = 0;
		//reading value of Storage and displaying it
		synchronized (s) {
			while (c < 9) {
				try {
					s.wait();
				} catch (InterruptedException ie) {
					System.out.println("Interrupted - " + ie.getMessage());
				}
				System.out.println(Thread.currentThread().getName() + " " + (c = s.getI()));
				s.notify();
			}
		}
	}
}
