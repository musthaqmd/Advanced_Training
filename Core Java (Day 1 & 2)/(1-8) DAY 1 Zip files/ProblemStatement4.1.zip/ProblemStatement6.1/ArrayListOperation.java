package com.org.day1;

import java.util.ArrayList;

public class ArrayListOperation {

	public static void main(String[] args) {

		// declaring ArrayList of type String
		ArrayList<String> list = new ArrayList<String>();

		// adding details into the ArrayList
		list.add("ABC");
		list.add("DEF");
		list.add("GHI");
		list.add("JKL");
		list.add("MNO");
		list.add("PQR");
		list.add("STU");

		System.out.println(list);

		// checking whether a detail is present in the ArrayList or not, returns true or
		// false
		System.out.println(list.contains("DEF"));
		System.out.println(list.contains("XYZ"));
	}
}
