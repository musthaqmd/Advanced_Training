package com.org.day1;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int l = 0, b = 0;

		// taking length and breadth from user
		System.out.println("Enter Length and Breadth of the Rectangle:");
		l = sc.nextInt();
		b = sc.nextInt();
		
		//checking whether length is less than breadth and length, breadth is less than 1
		if (l < b || l < 1 || b < 1)
			System.out.println("Please enter valid Length and Breadth");
		else {
			
			//creating objects of Rectangle
			Rectangle r1 = new Rectangle();
			Rectangle r2 = new Rectangle(l, b);
			Rectangle r3 = new Rectangle(l, b);
			Rectangle r4 = new Rectangle(l, b);
			Rectangle r5 = new Rectangle(l, b);

			r1.displayRect();
			r1.calcArea();

			r2.displayRect();
			r2.calcArea();

			r3.displayRect();
			r3.calcArea();

			r4.displayRect();
			r4.calcArea();

			r5.displayRect();
			r5.calcArea();
		}
	}
}
