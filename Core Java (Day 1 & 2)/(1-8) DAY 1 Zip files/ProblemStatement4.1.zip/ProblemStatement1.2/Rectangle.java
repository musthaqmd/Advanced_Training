package com.org.day1;

public class Rectangle {

	private int length;
	private int breadth;

	//default constructor
	public Rectangle() {
		this.length=0;
		this.breadth=0;
	}

	//parameterized constructor
	public Rectangle(int length, int breadth) {

		this.length = length;
		this.breadth = breadth;
	}

	//getters and setters
	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	//to display length and breadth
	public void displayRect() {
		System.out.println("Length of the rectangle is: " + length);
		System.out.println("Breadth of the rectangle is: " + breadth);
	}

	//to display area
	public void calcArea() {
		int area = length * breadth;
		System.out.println("Area of the rectangle is: " + area);
	}

}
