package com.org.day1;

import java.util.Scanner;

public class TestBook {

	// to create new book details
	public static void createBooks() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Book Title and Price: ");
		String title = s.nextLine();
		int price = s.nextInt();
		Book b = new Book();
		b.setBook_title(title);
		b.setBook_price(price);
		showBooks(b);
	}

	// to display book details
	public static void showBooks(Book book) {
		System.out.println("Book Title: " + book.getBook_title());
		System.out.println("Book Price: " + book.getBook_price());
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// taking number of books from the user
		System.out.println("Enter number of books:");
		int n = sc.nextInt();
		for (int i = 0; i < n; i++) {
			createBooks();
		}

	}
}
