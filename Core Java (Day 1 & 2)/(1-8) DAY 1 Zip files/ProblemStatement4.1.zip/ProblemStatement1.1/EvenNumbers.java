package com.org.day1;

import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int i, n;

		// taking number from user
		System.out.println("Enter a number:");
		n = sc.nextInt();
		for (i = 1; i <= n; i++) {
			// checking if the number is even or odd
			if (i % 2 == 0)
				System.out.print(i + " ");
		}
	}
}
