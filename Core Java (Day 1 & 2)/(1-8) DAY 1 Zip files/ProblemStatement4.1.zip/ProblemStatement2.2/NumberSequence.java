package com.org.day1;

import java.util.Scanner;

public class NumberSequence {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int a=0,b=0,s=0;
		
		//taking two numbers from user
		System.out.println("Enter two numbers:");
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.print(a+" "+b);
		
		//calculating the next 13 numbers in the sequence
		for(int i=1;i<=13;i++)
		{
			s=a+b;
			System.out.print(" "+s);
			a=b;
			b=s;
		}
	}
}
