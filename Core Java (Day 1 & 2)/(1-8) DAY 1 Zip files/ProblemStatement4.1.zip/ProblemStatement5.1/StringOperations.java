package com.org.day1;

public class StringOperations {

	public static void main(String[] args) {

		String str = "JAVA is Simple";

		// converts string to uppercase
		System.out.println(str.toUpperCase());

		// converts string to lowercase
		System.out.println(str.toLowerCase());

		// displays first letter of each word
		System.out.println(str.charAt(0) + " " + str.charAt(5) + " " + str.charAt(8));

		// changes place of words in the string
		String[] newstr = str.split("\\s");
		String newstr2 = newstr[2] + " " + newstr[1] + " " + newstr[0];
		System.out.println(newstr2);

		// reverses string
		StringBuilder s = new StringBuilder(newstr2);
		System.out.println(s.reverse());

		// display length of the string excluding whitespaces
		System.out.println("Total length is: " + str.replace(" ", "").length());
	}
}
